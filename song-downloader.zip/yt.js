async function ytSearch(query) {
  const r = await fetch("https://www.youtube.com/youtubei/v1/search?prettyPrint=false", {
    method: "POST", credentials: "omit",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ context: { client: { clientName: "WEB", clientVersion: "2.20250101.00.00", hl: "he", gl: "IL" } }, query })
  });
  if (!r.ok) throw new Error("החיפוש נכשל (" + r.status + ")");
  const j = await r.json();
  const out = [];
  const walk = (o) => {
    if (!o || typeof o !== "object") return;
    if (o.videoRenderer && o.videoRenderer.videoId) {
      const v = o.videoRenderer;
      out.push({
        id: v.videoId,
        title: (v.title.runs || []).map(x => x.text).join(""),
        channel: ((v.ownerText || {}).runs || []).map(x => x.text).join(""),
        length: (v.lengthText || {}).simpleText || ""
      });
      return;
    }
    for (const k in o) walk(o[k]);
  };
  walk(j);
  return out.slice(0, 8);
}

function parseVideoId(s) {
  s = s.trim();
  const m = s.match(/(?:v=|youtu\.be\/|shorts\/)([A-Za-z0-9_-]{11})/);
  if (m) return m[1];
  if (/^[A-Za-z0-9_-]{11}$/.test(s)) return s;
  return null;
}

async function ytAudio(videoId) {
  const r = await fetch("https://www.youtube.com/youtubei/v1/player?prettyPrint=false", {
    method: "POST", credentials: "omit",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      context: { client: { clientName: "ANDROID_VR", clientVersion: "1.60.19", deviceMake: "Oculus", deviceModel: "Quest 3", androidSdkVersion: 32, osName: "Android", osVersion: "12L", hl: "en" } },
      videoId, contentCheckOk: true, racyCheckOk: true
    })
  });
  if (!r.ok) throw new Error("לא הצלחתי לקבל את השיר (" + r.status + ")");
  const j = await r.json();
  const st = j.playabilityStatus || {};
  if (st.status !== "OK") throw new Error("יוטיוב לא מאפשר הורדה: " + (st.reason || st.status));
  const fmts = ((j.streamingData || {}).adaptiveFormats || []).filter(f => /^audio\/mp4/.test(f.mimeType) && f.url);
  if (!fmts.length) throw new Error("לא נמצא קובץ שמע להורדה");
  fmts.sort((a, b) => (b.bitrate || 0) - (a.bitrate || 0));
  const f = fmts[0];
  return { url: f.url, size: parseInt(f.contentLength || "0", 10), title: (j.videoDetails || {}).title || videoId };
}

async function fetchChunks(url, size, onProgress) {
  const parts = [];
  const CH = 9 * 1024 * 1024;
  let pos = 0;
  while (size === 0 || pos < size) {
    const end = size ? Math.min(pos + CH, size) - 1 : pos + CH - 1;
    const r = await fetch(url, { credentials: "omit", headers: { Range: "bytes=" + pos + "-" + end } });
    if (!(r.status === 200 || r.status === 206)) throw new Error("ההורדה נחסמה (" + r.status + ")");
    const b = await r.arrayBuffer();
    parts.push(b);
    pos += b.byteLength;
    if (onProgress && size) onProgress(Math.min(100, Math.round(pos * 100 / size)));
    if (!size && b.byteLength < CH) break;
    if (r.status === 200) break;
  }
  return new Blob(parts, { type: "audio/mp4" });
}

function cleanName(t) {
  return t.replace(/[\\/:*?"<>|]/g, " ").replace(/\s+/g, " ").trim().slice(0, 120) || "song";
}

async function uploadToDrive(blob, name) {
  const tok = await new Promise((res, rej) =>
    chrome.identity.getAuthToken({ interactive: true }, t => chrome.runtime.lastError || !t ? rej(new Error("אין הרשאה לדרייב")) : res(t)));
  const meta = { name, mimeType: "audio/mp4" };
  const boundary = "b" + Date.now();
  const body = new Blob([
    "--" + boundary + "\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n" + JSON.stringify(meta) + "\r\n",
    "--" + boundary + "\r\nContent-Type: audio/mp4\r\n\r\n", blob, "\r\n--" + boundary + "--"
  ]);
  const r = await fetch("https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart", {
    method: "POST", headers: { Authorization: "Bearer " + tok, "Content-Type": "multipart/related; boundary=" + boundary }, body
  });
  if (!r.ok) throw new Error("ההעלאה לדרייב נכשלה (" + r.status + ")");
}
