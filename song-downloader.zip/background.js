importScripts("config.js");
// מוסיף כללי כותרות כדי שהבקשות של התוסף ליוטיוב ייראו כמו האפליקציה הרשמית
const UA = "com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip";
async function setupRules() {
  const id = chrome.runtime.id;
  const hdr = (header, value) => ({ header, operation: "set", value });
  await chrome.declarativeNetRequest.updateDynamicRules({
    removeRuleIds: [1, 2],
    addRules: [
      {
        id: 1, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [
          hdr("User-Agent", UA), hdr("Origin", "https://www.youtube.com"),
          hdr("X-YouTube-Client-Name", "28"), hdr("X-YouTube-Client-Version", "1.60.19")] },
        condition: { urlFilter: "||www.youtube.com/youtubei/v1/player", initiatorDomains: [id], resourceTypes: ["xmlhttprequest"] }
      },
      {
        id: 2, priority: 1,
        action: { type: "modifyHeaders", requestHeaders: [hdr("User-Agent", UA)] },
        condition: { urlFilter: "||googlevideo.com/", initiatorDomains: [id], resourceTypes: ["xmlhttprequest"] }
      }
    ]
  });
}
chrome.runtime.onInstalled.addListener(setupRules);
chrome.runtime.onStartup.addListener(setupRules);

// חיבור לקו: בודק אם יש הזמנה חדשה מהטלפון
let polling = false;
async function pollLoop() {
  if (polling) return;
  polling = true;
  try {
    for (let i = 0; i < 20; i++) {
      const dev = await getDevice();
      const r = await fetch(RELAY_URL + "/api/next", { headers: authHeader(dev) });
      if (!r.ok) break;
      const job = await r.json();
      if (job && job.videoId) {
        const u = chrome.runtime.getURL("worker.html?v=" + job.videoId + "&dest=" + job.dest + "&job=" + job.id);
        await chrome.tabs.create({ url: u, active: false });
      }
    }
  } catch (e) {}
  polling = false;
}
chrome.alarms.create("poll", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener(a => { if (a.name === "poll") pollLoop(); });
chrome.runtime.onStartup.addListener(pollLoop);
chrome.runtime.onInstalled.addListener(pollLoop);
pollLoop();
