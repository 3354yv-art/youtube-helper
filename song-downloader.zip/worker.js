const p = new URLSearchParams(location.search);
const job = p.get("job");
const say = t => { document.getElementById("s").textContent = t; document.title = t; };
const report = async (ok, error) => {
  if (!job) return;
  try {
    const dev = await getDevice();
    await fetch(RELAY_URL + "/api/done", {
      method: "POST", headers: { ...authHeader(dev), "Content-Type": "application/json" },
      body: JSON.stringify({ id: job, ok, error: error || "" })
    });
  } catch (e) {}
};
async function saveLocal(blob, name) {
  const u = URL.createObjectURL(blob);
  // מהטלפון אין מי שיבחר תיקייה, לכן נשמר בתיקייה קבועה. מהתוסף עצמו נשאל לאן
  await chrome.downloads.download(job ? { url: u, filename: "שירים מהקו/" + name } : { url: u, filename: name, saveAs: true });
}
(async () => {
  try {
    say("מכין את השיר...");
    const a = await ytAudio(p.get("v"));
    const blob = await fetchChunks(a.url, a.size, n => say("מוריד " + n + "%"));
    const name = cleanName(a.title) + ".m4a";
    if (p.get("dest") === "drive") {
      say("מעלה לדרייב...");
      try { await uploadToDrive(blob, name); }
      catch (e) { if (!job) throw e; say("דרייב לא זמין, שומר במחשב..."); await saveLocal(blob, name); }
    } else {
      await saveLocal(blob, name);
    }
    await report(true);
    say("הסתיים: " + name);
    setTimeout(() => window.close(), 3000);
  } catch (e) { await report(false, e.message); say("שגיאה: " + e.message); }
})();
