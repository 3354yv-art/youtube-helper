const $ = id => document.getElementById(id);
const dest = () => document.querySelector('input[name=dest]:checked').value;
chrome.storage.local.get("dest", d => { if (d.dest) document.querySelector('input[value=' + d.dest + ']').checked = true; });
document.querySelectorAll('input[name=dest]').forEach(e => e.onchange = () => chrome.storage.local.set({ dest: dest() }));

function startDownload(id) {
  chrome.tabs.create({ url: chrome.runtime.getURL("worker.html?v=" + id + "&dest=" + dest()), active: false });
  $("msg").textContent = "ההורדה התחילה ברקע. אפשר לסגור את החלון.";
}

async function go() {
  const q = $("q").value.trim();
  if (!q) return;
  $("list").innerHTML = ""; $("msg").textContent = "";
  const id = parseVideoId(q);
  if (id) return startDownload(id);
  $("msg").textContent = "מחפש...";
  try {
    const res = await ytSearch(q);
    $("msg").textContent = res.length ? "" : "לא נמצאו תוצאות";
    for (const v of res) {
      const d = document.createElement("div"); d.className = "res";
      const t = document.createElement("b"); t.textContent = v.title;
      const s = document.createElement("span"); s.textContent = v.channel + " " + v.length + " ";
      const b = document.createElement("button"); b.textContent = "הורד"; b.onclick = () => startDownload(v.id);
      d.append(t, s, b); $("list").append(d);
    }
  } catch (e) { $("msg").textContent = e.message; }
}
$("go").onclick = go;
$("q").onkeydown = e => { if (e.key === "Enter") go(); };

// זיהוי סרטון יוטיוב בדף הפתוח (כולל סרטון מוטמע באתרים כמו נטיוב)
(async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab || !tab.id || !/^https?:/.test(tab.url || "")) return;
    const [r] = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        const ids = [];
        const re = /(?:youtube(?:-nocookie)?\.com\/(?:embed\/|watch\?v=)|youtu\.be\/)([A-Za-z0-9_-]{11})/;
        const m0 = location.href.match(re); if (m0) ids.push(m0[1]);
        document.querySelectorAll("iframe").forEach(f => { const m = (f.src || f.dataset.src || "").match(re); if (m) ids.push(m[1]); });
        return { id: ids[0] || null, title: document.title };
      }
    });
    if (r && r.result && r.result.id) {
      $("page").style.display = "block";
      $("ptitle").textContent = "נמצא סרטון בדף: " + r.result.title;
      $("pgo").onclick = () => startDownload(r.result.id);
    }
  } catch (e) {}
})();

(async () => {
  $("lp").textContent = LINE_PHONE; $("le").textContent = LINE_EXT;
  try {
    const dev = await getDevice();
    $("code").textContent = dev.code;
    const { phone } = await chrome.storage.local.get("phone");
    const showDone = ph => { $("phoneRow").style.display = "none"; $("phoneDone").style.display = "block"; $("phoneDone").textContent = "רשום למספר " + ph + ". אפשר להתקשר."; };
    if (phone) showDone(phone);
    $("savePhone").onclick = async () => {
      try {
        const r = await fetch(RELAY_URL + "/api/phone", { method: "POST", headers: { ...authHeader(dev), "Content-Type": "application/json" }, body: JSON.stringify({ phone: $("phone").value }) });
        if (!r.ok) { $("msg").textContent = "מספר לא תקין"; return; }
        const j = await r.json(); await chrome.storage.local.set({ phone: j.phone }); showDone(j.phone);
      } catch (e) { $("msg").textContent = "אין חיבור לשרת"; }
    };
  } catch (e) { $("code").textContent = "אין חיבור לשרת"; }
})();
