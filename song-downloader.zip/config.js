const RELAY_URL = "http://129.159.151.3:8787";
const LINE_PHONE = "0772271152";
const LINE_EXT = "70";

// רישום אוטומטי בהתקנה: כל משתמש מקבל קוד אישי
async function getDevice() {
  let { device } = await chrome.storage.local.get("device");
  if (device && device.id) return device;
  const r = await fetch(RELAY_URL + "/api/register", { method: "POST" });
  if (!r.ok) throw new Error("הרישום נכשל");
  device = await r.json();
  await chrome.storage.local.set({ device });
  return device;
}
const authHeader = d => ({ Authorization: "Bearer " + d.id + ":" + d.secret });
